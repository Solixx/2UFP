//
// Created by manue on 25/10/2022.
//

#ifndef ANO2_TESTES_H
#define ANO2_TESTES_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

int main_testes(int argc, const char * argv[]);

#endif //ANO2_TESTES_H
